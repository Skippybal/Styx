
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include <arpa/inet.h>
#include <netinet/in.h>

#include <sys/types.h>
#include <sys/socket.h>
    
void writeCPUTime(double cpuTime);

int main(int argc, char** argv)
{
  int i=0;
  for(i=0; i < 1000000; i++)
  {   
    //usleep(1000);
    writeCPUTimeToSocket(1.021*i+0.84*i*i);
  }
  
}

static FILE *fp;

void writeCPUTimeToSocket(double cpuTime)
{
  
  
  char* portstr = getenv("ACLIB_PORT");
  
  if(portstr == NULL)
  {
    return;
  }
  
  int port = strtol(portstr,NULL, 10);
  
  if(port < 1024 || port > 65535)
  { //Invalid port, probably nothing
    return;
  }
    
  static struct sockaddr_in servaddr;
 
  
  static double updateFreqDbl = 1;
  static int lastUpdate = -1;

  static int sockfd = -1;
  
  if(sockfd == -1)
  {
      sockfd=socket(AF_INET,SOCK_DGRAM,0);
     
      bzero(&servaddr,sizeof(servaddr));
      servaddr.sin_family = AF_INET;
      servaddr.sin_addr.s_addr=inet_addr("127.0.0.1");
      servaddr.sin_port=htons(port);
  }
  
  char* updateFreq = getenv("ACLIB_CPU_TIME_FREQUENCY");
       
  if(updateFreq != NULL)
  {
      updateFreqDbl = strtod(updateFreq, NULL);
      
      if(updateFreqDbl < 1)
      {
        updateFreqDbl = 1;
      }
  }
  
  if((time(NULL) - lastUpdate) > updateFreqDbl || 1)
  {
    lastUpdate = time(NULL);
    
    char buf[100];
    bzero(buf, 100);
    
    sprintf(buf, "%f", cpuTime);
    //Not sure if MSG_DONTWAIT is appropriate, maybe though
    sendto(sockfd, buf, strlen(buf), 0, (struct sockaddr*) &servaddr, sizeof(servaddr));
    return;
  } 
  
  return;
}


/*
void writeCPUTime(double cpuTime)
{
  
  

  
  static double updateFreqDbl = 1;
  static int lastUpdate = -1;
  
  if(lastUpdate)
 
  
  
  
  if(fp == NULL)
  {
    char* filename = getenv("ACLIB_CPU_TIME_FILE");
    if(filename == NULL)
    {
      printf("No file");
      return;
    }
    char* updateFreq = getenv("ACLIB_CPU_TIME_FREQUENCY");
    
   
    if(updateFreq != NULL)
    {
      updateFreqDbl = strtod(updateFreq, NULL)
      
      if(updateFreqDbl < 1)
      {
        updateFreqDbl = 1;
      }
    }
    fp = fopen(filename,"w");
  }
  
  if(lastUpdate == -1)
  {
    return;
  } else if( (time(NULL) - lastUpdate) > updateFreqDbl )
  {
    lastUpdate = time(NULL)
  }
  
   //char* outputPtr = &output;
   rewind(fp);
   fprintf(fp,"%f",cpuTime);
   fflush(fp);
   
   //printf("Writing %s ",output);
   //fwrite(output,1,strlen(output),fp);
   // fclose(fp);
    
   // free(output);
   
   
  
    return;
}
*/
